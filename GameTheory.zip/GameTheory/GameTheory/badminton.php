<?php
// Connecting to the Database
$servername = "172.16.15.7"; // Change as needed
$username = "root"; // Change as needed
$password = ""; // Change as needed
$database = "dbms19"; // Change as needed

// Create a connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $date = $_POST['date'];
    $time = $_POST['time'];
    $court = $_POST['court'];

    // Insert the booking into the database
    $sql = "INSERT INTO badminton_bookings (date, time, court) VALUES (?, ?, ?)";
    
    // Prepare and bind the statement
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $date, $time, $court);

    // Execute the statement
    if ($stmt->execute()) {
        echo "<div class='pop-up-container'><p class='pop-up'>Booking successful for Court $court on $date at $time!</p></div>";
    } else {
        echo "<div class='pop-up-container'><p class='pop-up'>Error: " . $stmt->error . "</p></div>";
    }

    // Close the statement
    $stmt->close();
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sportify - Booking Confirmation</title>
    <style>
        .pop-up {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            border-radius: 5px;
            font-weight: bold;
            text-align: center;
            margin-top: 20px;
        }
        .pop-up-container {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 9999;
        }
    </style>
</head>
<body>
    <h1>Thank You for Booking!</h1>
    <p>Your booking details will be sent to your email.</p>
    <a href="badminton.html">Go back to Booking Page</a>
</body>
</html>
