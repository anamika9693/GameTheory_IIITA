<?php
// connect to the database
require_once 'config.php';

// Retrieve the parameters from the GET request
$center_id = $_GET['center_id'] ?? null;
$sport = $_GET['sport'] ?? null;
$booking_date = $_GET['booking_date'] ?? null;

// Construct the SQL query
$sql = "SELECT * FROM bookings WHERE 1=1";

if ($center_id) {
    $sql .= " AND center_id = '$center_id'";
}
if ($sport) {
    $sql .= " AND sport = '$sport'";
}
if ($booking_date) {
    $sql .= " AND booking_date = '$booking_date'";
}

// Execute the query
$result = mysqli_query($conn, $sql);

$bookings = [];

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $bookings[] = $row;
    }
}

// Return the results in JSON format
header('Content-Type: application/json');
echo json_encode($bookings);

mysqli_close($conn);
?>
