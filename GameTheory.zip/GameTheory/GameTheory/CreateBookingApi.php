<?php
// connect to the database
require_once 'config.php';

// Retrieve the POST data from the request
$user_id = $_POST['user_id'];
$sport = $_POST['sport'];
$center_id = $_POST['center_id'];
$court = $_POST['court'];
$booking_date = $_POST['booking_date'];
$time_slot = $_POST['time_slot'];

// Check if the booking conflicts with an existing booking
$sql_check = "SELECT * FROM bookings 
              WHERE center_id = '$center_id' 
              AND court = '$court' 
              AND booking_date = '$booking_date' 
              AND time_slot = '$time_slot'";

$result_check = mysqli_query($conn, $sql_check);

if (mysqli_num_rows($result_check) > 0) {
    // Booking conflict exists
    $response = [
        "status" => "error",
        "message" => "The time slot is already booked."
    ];
} else {
    // Insert the new booking
    $sql_insert = "INSERT INTO bookings (user_id, sport, center_id, court, booking_date, time_slot) 
                   VALUES ('$user_id', '$sport', '$center_id', '$court', '$booking_date', '$time_slot')";

    if (mysqli_query($conn, $sql_insert)) {
        $response = [
            "status" => "success",
            "message" => "Booking created successfully"
        ];
    } else {
        $response = [
            "status" => "error",
            "message" => "Failed to create booking"
        ];
    }
}

// Return the response in JSON format
header('Content-Type: application/json');
echo json_encode($response);

mysqli_close($conn);
?>
