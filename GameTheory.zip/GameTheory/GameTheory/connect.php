<?php
// Database configuration
$host = 'localhost'; // Your database host
$db_name = 'your_database_name'; // Your database name
$username = 'your_username'; // Your database username
$password = 'your_password'; // Your database password

// Create a database connection
$conn = new mysqli($host, $username, $password, $db_name);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $sport = $conn->real_escape_string($_POST['sport']);
    $plan = $conn->real_escape_string($_POST['plan']);
    $startDate = $conn->real_escape_string($_POST['startDate']);
    $endDate = $conn->real_escape_string($_POST['endDate']);
    $experience = $conn->real_escape_string($_POST['experience']);
    $goals = $conn->real_escape_string($_POST['goals']);
    $medicalInfo = $conn->real_escape_string($_POST['medicalInfo']);

    // Prepare and execute the SQL statement
    $sql = "INSERT INTO registrations (name, email, phone, sport, plan, start_date, end_date, experience, goals, medical_info) 
            VALUES ('$name', '$email', '$phone', '$sport', '$plan', '$startDate', '$endDate', '$experience', '$goals', '$medicalInfo')";

    if ($conn->query($sql) === TRUE) {
        // Successful registration
        echo "New record created successfully.";
        // Optionally redirect to a thank you page or display a success message
        // header("Location: thank_you.php");
    } else {
        // Error occurred
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>
