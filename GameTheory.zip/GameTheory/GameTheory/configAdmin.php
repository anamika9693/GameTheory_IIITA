<?php 
// Database configuration for admin access
define('DB_SERVER', '172.16.15.7');  // Database server address
define('DB_USERNAME', 'dbms19');      // Database username
define('DB_PASSWORD', 'dbms@19');     // Database password
define('DB_NAME', 'dbms19');          // Database name

// Establishing connection to the database
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check connection
if ($link == false) {
    die('Error: Unable to connect to the database');
}
?>
