<?php
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$database = "sports_management";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieve form data
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$sport = $_POST['sport'];
$plan = $_POST['plan'];
$startDate = $_POST['startDate'];
$endDate = $_POST['endDate'];
$experience = $_POST['experience'];
$goals = $_POST['goals'];
$medicalInfo = $_POST['medicalInfo'];

// Insert registration data into the users table
$sql_user = "INSERT INTO users (name, email, phone, sport, plan, start_date, end_date, experience, goals, medical_info) 
VALUES ('$name', '$email', '$phone', '$sport', '$plan', '$startDate', '$endDate', '$experience', '$goals', '$medicalInfo')";

// Execute the query
if (mysqli_query($conn, $sql_user)) {
    // If the sport is badminton, also insert a booking record
    if ($sport === 'badminton') {
        $sql_booking = "INSERT INTO bookings (user, date, time_slot, court, sport) 
        VALUES ('$name', '$startDate', '09:00 - 10:00', 'Court 1', 'Badminton')"; // Example values for date and time_slot
        mysqli_query($conn, $sql_booking);
    }
    echo "Registration successful!";
} else {
    echo "Error: " . $sql_user . "<br>" . mysqli_error($conn);
}

// Close the connection
mysqli_close($conn);
?>
