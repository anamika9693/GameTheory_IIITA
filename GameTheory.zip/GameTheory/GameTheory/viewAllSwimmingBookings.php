<?php
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$database = "sports_management";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch all swimming bookings
$sql = "SELECT * FROM bookings WHERE sport = 'Swimming'";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Swimming Pool Bookings</title>
    <link rel="stylesheet" href="viewBookings.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:hover {
            background-color: #f5f5f5;
        }
    </style>
</head>

<body>
    <h1>Swimming Pool Bookings</h1>
    
    <table>
        <tr>
            <th>Booking ID</th>
            <th>User</th>
            <th>Date</th>
            <th>Time Slot</th>
            <th>Pool</th>
        </tr>
        
        <?php
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                        <td>" . htmlspecialchars($row["booking_id"]) . "</td>
                        <td>" . htmlspecialchars($row["user"]) . "</td>
                        <td>" . htmlspecialchars($row["date"]) . "</td>
                        <td>" . htmlspecialchars($row["time_slot"]) . "</td>
                        <td>" . htmlspecialchars($row["court"]) . "</td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='5'>No swimming bookings found</td></tr>";
        }
        ?>
    </table>
</body>

</html>

<?php
// Close the connection
mysqli_close($conn);
?>
